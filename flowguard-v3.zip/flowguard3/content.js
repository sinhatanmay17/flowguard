// FlowGuard v3 Content Script
(function(){
  'use strict';
  let overlayEl=null;

  function removeOverlay(){
    if(overlayEl){ overlayEl.style.opacity='0'; overlayEl.style.transform='scale(0.96)'; setTimeout(()=>{overlayEl?.remove();overlayEl=null;},250); }
  }

  function injectStyles(){
    if(document.getElementById('fg-styles')) return;
    const s=document.createElement('style');
    s.id='fg-styles';
    s.textContent=`
      #fg-overlay{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;opacity:0;transform:scale(0.96);transition:all .25s cubic-bezier(.34,1.56,.64,1)}
      #fg-overlay.show{opacity:1;transform:scale(1)}
      .fg-bd{position:absolute;inset:0;backdrop-filter:blur(12px)}
      .fg-bd-normal{background:rgba(255,255,255,0.85)}
      .fg-bd-ultra{background:rgba(10,10,20,0.92)}
      .fg-card{position:relative;z-index:1;border-radius:20px;padding:32px 28px;max-width:380px;width:90%;text-align:center}
      .fg-card-normal{background:#fff;border:1px solid #e5e7eb;box-shadow:0 20px 60px rgba(0,0,0,0.12),0 0 0 1px rgba(0,0,0,0.04)}
      .fg-card-ultra{background:#0a0a14;border:1px solid rgba(244,63,94,0.3);box-shadow:0 20px 60px rgba(0,0,0,0.8),0 0 40px rgba(244,63,94,0.1)}
      .fg-icon{font-size:40px;margin-bottom:10px;display:block}
      .fg-badge-normal{display:inline-block;background:#f3f4f6;color:#6b7280;font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;padding:3px 10px;border-radius:99px;margin-bottom:14px}
      .fg-badge-ultra{display:inline-block;background:rgba(244,63,94,0.15);color:#f43f5e;font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;padding:3px 10px;border-radius:99px;margin-bottom:14px;border:1px solid rgba(244,63,94,0.3)}
      .fg-title-normal{font-size:18px;font-weight:700;color:#111827;margin:0 0 8px}
      .fg-title-ultra{font-size:18px;font-weight:700;color:#fff;margin:0 0 8px}
      .fg-goal-normal{background:#f9fafb;border-radius:10px;padding:9px 12px;font-size:12px;color:#6b7280;margin:0 0 16px;border:1px solid #f3f4f6}
      .fg-goal-ultra{background:rgba(255,255,255,0.05);border-radius:10px;padding:9px 12px;font-size:12px;color:#9ca3af;margin:0 0 16px;border:1px solid rgba(255,255,255,0.08)}
      .fg-goal strong{color:#111827}.fg-goal-ultra strong{color:#e5e7eb}
      .fg-stats{display:flex;gap:10px;justify-content:center;margin-bottom:16px}
      .fg-stat-normal{background:#f9fafb;border:1px solid #f3f4f6;border-radius:10px;padding:9px 14px;display:flex;flex-direction:column;align-items:center}
      .fg-stat-ultra{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:9px 14px;display:flex;flex-direction:column;align-items:center}
      .fg-stat-num-normal{font-size:18px;font-weight:800;color:#6366f1}
      .fg-stat-num-ultra{font-size:18px;font-weight:800;color:#f43f5e}
      .fg-stat-lbl{font-size:10px;color:#9ca3af;margin-top:2px}
      .fg-q-normal{font-size:13px;color:#374151;margin:0 0 16px}
      .fg-q-ultra{font-size:13px;color:#d1d5db;margin:0 0 16px}
      .fg-actions{display:flex;gap:8px;margin-bottom:12px}
      .fg-btn{flex:1;padding:10px;border-radius:10px;font-size:13px;font-weight:600;cursor:pointer;border:none;transition:all .15s}
      .fg-back-normal{background:#111827;color:#fff}.fg-back-normal:hover{background:#374151;transform:translateY(-1px)}
      .fg-back-ultra{background:#f43f5e;color:#fff}.fg-back-ultra:hover{background:#e11d48;transform:translateY(-1px)}
      .fg-skip-normal{background:#f3f4f6;color:#6b7280;border:1px solid #e5e7eb}.fg-skip-normal:hover{background:#e5e7eb}
      .fg-skip-ultra{background:rgba(255,255,255,0.07);color:#6b7280;border:1px solid rgba(255,255,255,0.08)}.fg-skip-ultra:hover{background:rgba(255,255,255,0.1)}
      .fg-note{font-size:10px;color:#9ca3af;margin:0}
      .fg-locked{font-size:11px;font-weight:600;color:#f43f5e;margin-top:4px}
      #fg-bar{position:fixed;top:0;left:0;right:0;z-index:2147483646;padding:7px 16px;display:flex;align-items:center;justify-content:space-between;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;font-size:12px;transform:translateY(-100%);transition:transform .3s cubic-bezier(.34,1.56,.64,1);background:#fff;border-bottom:1px solid #e5e7eb;box-shadow:0 2px 8px rgba(0,0,0,0.06)}
      #fg-bar.show{transform:translateY(0)}
      .fg-bar-score{background:#f3f4f6;border-radius:99px;padding:2px 8px;font-weight:700;color:#6b7280;font-size:11px}
      #fg-bar-x{background:none;border:none;cursor:pointer;color:#9ca3af;font-size:15px;padding:0;line-height:1}
      #fg-bar-x:hover{color:#374151}`;
    document.head.appendChild(s);
  }

  function createOverlay({goal,attempts,elapsed,ultraFocus}){
    removeOverlay();
    injectStyles();
    const ultra=!!ultraFocus;
    const el=document.createElement('div');
    el.id='fg-overlay';
    el.innerHTML=`
      <div class="fg-bd ${ultra?'fg-bd-ultra':'fg-bd-normal'}"></div>
      <div class="fg-card ${ultra?'fg-card-ultra':'fg-card-normal'}">
        <span class="fg-icon">${ultra?'🔒':'🛡️'}</span>
        <span class="${ultra?'fg-badge-ultra':'fg-badge-normal'}">${ultra?'Ultra Focus':'FlowGuard'}</span>
        <h2 class="${ultra?'fg-title-ultra':'fg-title-normal'}">${ultra?'Site Blocked':'Distraction Detected'}</h2>
        <p class="${ultra?'fg-goal-ultra':'fg-goal-normal'}">Goal: <strong>"${esc(goal)}"</strong></p>
        <div class="fg-stats">
          <div class="${ultra?'fg-stat-ultra':'fg-stat-normal'}"><span class="${ultra?'fg-stat-num-ultra':'fg-stat-num-normal'}">${elapsed}m</span><span class="fg-stat-lbl">elapsed</span></div>
          <div class="${ultra?'fg-stat-ultra':'fg-stat-normal'}"><span class="${ultra?'fg-stat-num-ultra':'fg-stat-num-normal'}">${attempts}</span><span class="fg-stat-lbl">blocked</span></div>
          <div class="${ultra?'fg-stat-ultra':'fg-stat-normal'}"><span class="${ultra?'fg-stat-num-ultra':'fg-stat-num-normal'}">-5</span><span class="fg-stat-lbl">focus pts</span></div>
        </div>
        <p class="${ultra?'fg-q-ultra':'fg-q-normal'}">${ultra?'Ultra Focus is active. This site is not on your whitelist.':'This site looks like a distraction. Stay on track!'}</p>
        <div class="fg-actions">
          <button class="fg-btn ${ultra?'fg-back-ultra':'fg-back-normal'}" id="fg-back">← Go Back</button>
          ${ultra?`<button class="fg-btn fg-skip-ultra" id="fg-skip" disabled style="opacity:.4;cursor:not-allowed">Locked 🔒</button>`:`<button class="fg-btn fg-skip-normal" id="fg-skip">Continue Anyway</button>`}
        </div>
        <p class="fg-note">${ultra?'To allow this site, add it to your session whitelist before starting.':'Each distraction costs 5 focus points'}</p>
        ${ultra?`<p class="fg-locked">Ultra Focus — no override allowed</p>`:''}
      </div>`;
    document.body.appendChild(el);
    overlayEl=el;
    requestAnimationFrame(()=>el.classList.add('show'));
    el.querySelector('#fg-back').addEventListener('click',()=>{ removeOverlay(); history.back(); });
    if (!ultra) el.querySelector('#fg-skip').addEventListener('click',removeOverlay);
  }

  function createBar({score,goal}){
    document.getElementById('fg-bar')?.remove();
    injectStyles();
    const bar=document.createElement('div');
    bar.id='fg-bar';
    bar.innerHTML=`<div style="display:flex;align-items:center;gap:8px;color:#374151">🛡️ <span class="fg-bar-score">${score}% relevant</span> Off-track from: <em style="color:#6b7280">"${esc(goal.substring(0,40))}…"</em></div><button id="fg-bar-x">✕</button>`;
    document.body.appendChild(bar);
    requestAnimationFrame(()=>bar.classList.add('show'));
    bar.querySelector('#fg-bar-x').addEventListener('click',()=>{ bar.style.transform='translateY(-100%)'; setTimeout(()=>bar.remove(),300); });
    setTimeout(()=>{ bar.style.transform='translateY(-100%)'; setTimeout(()=>bar.remove(),300); },6000);
  }

  function esc(s){ return (s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

  chrome.runtime.onMessage.addListener((msg)=>{
    if (msg.type==='SHOW_DISTRACTION_WARNING') createOverlay(msg);
    if (msg.type==='SHOW_LOW_RELEVANCE') createBar(msg);
  });
})();
