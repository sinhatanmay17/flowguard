// FlowGuard v3 Background Service Worker

const LEVELS = [
  { level:1,  xpRequired:0,     title:"Distracted Freshman",  icon:"🌱" },
  { level:2,  xpRequired:100,   title:"Curious Sophomore",    icon:"📖" },
  { level:3,  xpRequired:250,   title:"Focused Junior",       icon:"🎯" },
  { level:4,  xpRequired:500,   title:"Dedicated Senior",     icon:"💪" },
  { level:5,  xpRequired:900,   title:"Research Apprentice",  icon:"🔬" },
  { level:6,  xpRequired:1400,  title:"Study Warrior",        icon:"⚔️" },
  { level:7,  xpRequired:2000,  title:"Flow Seeker",          icon:"🌊" },
  { level:8,  xpRequired:2800,  title:"Deep Worker",          icon:"🧠" },
  { level:9,  xpRequired:3800,  title:"Insight Hunter",       icon:"🦅" },
  { level:10, xpRequired:5000,  title:"Knowledge Adept",      icon:"✨" },
  { level:11, xpRequired:6500,  title:"Focus Master",         icon:"🎖️" },
  { level:12, xpRequired:8500,  title:"Zen Scholar",          icon:"🧘" },
  { level:13, xpRequired:11000, title:"Flow Champion",        icon:"🏆" },
  { level:14, xpRequired:14000, title:"Deep Sage",            icon:"🌙" },
  { level:15, xpRequired:18000, title:"Elite Researcher",     icon:"💎" },
  { level:16, xpRequired:23000, title:"Grand Scholar",        icon:"👑" },
  { level:17, xpRequired:29000, title:"Ascended Thinker",     icon:"🌟" },
  { level:18, xpRequired:36000, title:"Mythic Intellect",     icon:"⚡" },
  { level:19, xpRequired:44000, title:"Transcendent Mind",    icon:"🔮" },
  { level:20, xpRequired:54000, title:"Legendary Scholar",    icon:"🌌" }
];

const BADGES = [
  { id:"first_blood",  name:"First Session",   icon:"🎯", desc:"Complete your first focus session",  check:(s)=>s.totalSessions>=1 },
  { id:"triple",       name:"Hat Trick",        icon:"🎩", desc:"Complete 3 sessions",                check:(s)=>s.totalSessions>=3 },
  { id:"ten_sessions", name:"Grind Mode",       icon:"⚙️", desc:"Complete 10 sessions",               check:(s)=>s.totalSessions>=10 },
  { id:"fifty",        name:"Dedicated",        icon:"🏅", desc:"Complete 50 sessions",               check:(s)=>s.totalSessions>=50 },
  { id:"streak3",      name:"On Fire",          icon:"🔥", desc:"3-day streak",                       check:(s)=>s.longestStreak>=3 },
  { id:"streak7",      name:"Week Warrior",     icon:"🗓️", desc:"7-day streak",                       check:(s)=>s.longestStreak>=7 },
  { id:"streak30",     name:"Unstoppable",      icon:"⚡", desc:"30-day streak",                      check:(s)=>s.longestStreak>=30 },
  { id:"perfect",      name:"Perfectionist",    icon:"💯", desc:"Achieve 100 focus score",            check:(s)=>s.hasPerfectScore },
  { id:"clean_week",   name:"Clean Week",       icon:"✨", desc:"7 sessions above 80 score",          check:(s)=>s.highScoreStreak>=7 },
  { id:"marathon",     name:"Marathon",         icon:"🏃", desc:"Complete a 90-min session",          check:(s)=>s.longestSession>=90 },
  { id:"ultra",        name:"Ultra Focused",    icon:"🔒", desc:"Complete an Ultra Focus session",    check:(s)=>s.ultraSessions>=1 },
  { id:"night_owl",    name:"Night Owl",        icon:"🦉", desc:"Focus session after midnight",       check:(s)=>s.nightOwl },
  { id:"early_bird",   name:"Early Bird",       icon:"🐦", desc:"Focus session before 7am",           check:(s)=>s.earlyBird },
  { id:"xp1000",       name:"XP Hunter",        icon:"💰", desc:"Earn 1,000 total XP",                check:(s)=>s.totalXP>=1000 },
  { id:"xp10000",      name:"XP Hoarder",       icon:"💎", desc:"Earn 10,000 total XP",               check:(s)=>s.totalXP>=10000 },
  { id:"challenge5",   name:"Challenger",       icon:"🎖️", desc:"Complete 5 daily challenges",        check:(s)=>s.challengesCompleted>=5 },
];

const DAILY_CHALLENGES = [
  { id:"d1", text:"Complete 2 focus sessions today",   xpReward:50  },
  { id:"d2", text:"Focus for 60+ total minutes today", xpReward:75  },
  { id:"d3", text:"Achieve 80+ focus score",           xpReward:60  },
  { id:"d4", text:"Zero distractions in a session",    xpReward:100 },
  { id:"d5", text:"Complete a 45-min session",         xpReward:80  },
  { id:"d6", text:"Start a session before noon",       xpReward:40  },
  { id:"d7", text:"Complete 3 sessions today",         xpReward:120 },
];

const WEEKLY_CHALLENGES = [
  { id:"w1", text:"Focus for 5 hours this week",       xpReward:300 },
  { id:"w2", text:"Complete 10 sessions this week",    xpReward:250 },
  { id:"w3", text:"Maintain a 5-day streak",           xpReward:400 },
  { id:"w4", text:"Average focus score above 75",      xpReward:350 },
  { id:"w5", text:"Complete 3 Ultra Focus sessions",   xpReward:500 },
];

const DEFAULT_BLOCKLIST = [
  'youtube.com','netflix.com','instagram.com','twitter.com','x.com',
  'facebook.com','tiktok.com','reddit.com','twitch.tv','pinterest.com',
  'snapchat.com','discord.com','whatsapp.com','telegram.org',
  '9gag.com','buzzfeed.com','tumblr.com','quora.com','vk.com',
  'linkedin.com','twitch.tv','hulu.com','primevideo.com','disneyplus.com'
];

let session = null;

// ── Helpers ───────────────────────────────────────────────────────────────────
function extractDomain(url) {
  try { return new URL(url).hostname.replace('www.',''); } catch { return ''; }
}

function isBlocked(url, customBlocklist, globalWhitelist, sessionWhitelist, ultraFocus, removedDefaults) {
  const domain = extractDomain(url);
  if (!domain) return false;
  const allWhitelisted = [...(globalWhitelist||[]), ...(sessionWhitelist||[])];
  if (allWhitelisted.some(w => domain.includes(w))) return false;
  if (ultraFocus) return true;
  const activeDefaults = DEFAULT_BLOCKLIST.filter(d => !(removedDefaults||[]).includes(d));
  const allBlocked = [...activeDefaults, ...(customBlocklist||[])];
  return allBlocked.some(d => domain.includes(d));
}

function getKeywords(goal) {
  const stop = new Set(['a','an','the','and','or','for','to','of','in','on','with','my','i','about','is','are','was']);
  return goal.toLowerCase().split(/\s+/).filter(w => w.length>2 && !stop.has(w));
}

function scoreRelevance(url, title, keywords) {
  if (!keywords.length) return 50;
  const text = (url+' '+(title||'')).toLowerCase();
  const matched = keywords.filter(k => text.includes(k));
  return Math.round((matched.length/keywords.length)*100);
}

function calcXP(durationMins, score, ultraFocus) {
  const base = durationMins * 2;
  const mult = score>=90?2.0:score>=75?1.5:score>=60?1.2:score>=40?1.0:0.7;
  const ultraBonus = ultraFocus ? 1.5 : 1.0;
  return Math.round(base * mult * ultraBonus);
}

function getLevelInfo(totalXP) {
  let cur=LEVELS[0], nxt=LEVELS[1];
  for (let i=LEVELS.length-1;i>=0;i--) {
    if (totalXP>=LEVELS[i].xpRequired) { cur=LEVELS[i]; nxt=LEVELS[i+1]||null; break; }
  }
  const into=totalXP-cur.xpRequired, needed=nxt?nxt.xpRequired-cur.xpRequired:1;
  return { current:cur, next:nxt, progress:nxt?Math.min((into/needed)*100,100):100 };
}

function getActiveChallenges() {
  const di=Math.floor(Date.now()/86400000), wi=Math.floor(Date.now()/(86400000*7));
  return { daily:DAILY_CHALLENGES[di%DAILY_CHALLENGES.length], weekly:WEEKLY_CHALLENGES[wi%WEEKLY_CHALLENGES.length] };
}

function today() { return new Date().toDateString(); }
function weekStart() { const d=new Date(); d.setDate(d.getDate()-d.getDay()); return d.toDateString(); }

// ── Session ───────────────────────────────────────────────────────────────────
async function startSession(goal, duration, sessionWhitelist, ultraFocus) {
  const now = Date.now();
  session = {
    goal, duration:duration*60000,
    startTime:now, endTime:now+duration*60000,
    keywords:getKeywords(goal),
    sessionWhitelist:sessionWhitelist||[],
    ultraFocus:!!ultraFocus,
    distractionAttempts:0, tabsOpened:0, focusScore:100
  };
  await chrome.storage.local.set({ activeSession:session });
  chrome.alarms.create('sessionEnd', { when:session.endTime });
  chrome.alarms.create('sessionTick', { periodInMinutes:1 });
  updateBadge(true, ultraFocus);
}

async function endSession(completed=false) {
  if (!session) return;
  const elapsed = Date.now()-session.startTime;
  const durationMins = Math.round(elapsed/60000);
  const xpEarned = calcXP(durationMins, session.focusScore, session.ultraFocus);
  const hour = new Date().getHours();

  const data = await chrome.storage.local.get([
    'sessionHistory','streakData','playerStats','completedChallenges',
    'challengeProgress','earnedBadges','leaderboard'
  ]);

  const history = data.sessionHistory||[];
  const streakData = data.streakData||{current:0,longest:0,lastDate:null};
  const playerStats = data.playerStats||{totalXP:0,totalSessions:0,longestStreak:0,hasPerfectScore:false,highScoreStreak:0,longestSession:0,nightOwl:false,earlyBird:false,challengesCompleted:0,ultraSessions:0};
  const earnedBadges = data.earnedBadges||[];
  const leaderboard = data.leaderboard||[];

  const todayStr=today(), yesterday=new Date(Date.now()-86400000).toDateString();
  if (streakData.lastDate!==todayStr) {
    streakData.current = streakData.lastDate===yesterday ? streakData.current+1 : 1;
    streakData.longest = Math.max(streakData.longest, streakData.current);
    streakData.lastDate = todayStr;
  }

  playerStats.totalXP=(playerStats.totalXP||0)+xpEarned;
  playerStats.totalSessions=(playerStats.totalSessions||0)+1;
  playerStats.longestStreak=Math.max(playerStats.longestStreak||0,streakData.longest);
  if (session.focusScore===100) playerStats.hasPerfectScore=true;
  if (session.focusScore>=80) playerStats.highScoreStreak=(playerStats.highScoreStreak||0)+1;
  else playerStats.highScoreStreak=0;
  playerStats.longestSession=Math.max(playerStats.longestSession||0,durationMins);
  if (hour>=0&&hour<5) playerStats.nightOwl=true;
  if (hour>=5&&hour<7) playerStats.earlyBird=true;
  if (session.ultraFocus) playerStats.ultraSessions=(playerStats.ultraSessions||0)+1;

  const prevLevel=getLevelInfo(playerStats.totalXP-xpEarned);
  const newLevel=getLevelInfo(playerStats.totalXP);
  const leveledUp=newLevel.current.level>prevLevel.current.level;

  const newBadgeIds=[];
  for (const badge of BADGES) {
    if (!earnedBadges.includes(badge.id) && badge.check(playerStats)) {
      earnedBadges.push(badge.id); newBadgeIds.push(badge.id);
    }
  }

  const cp=data.challengeProgress||{date:todayStr,week:weekStart(),sessionsToday:0,minsToday:0,bestScoreToday:0,perfectSessionToday:false,longestSessionToday:0,morningSession:false,sessionsThisWeek:0,minsThisWeek:0,avgScoreThisWeek:0,cleanSessionsThisWeek:0,ultraSessionsThisWeek:0,scoresThisWeek:[],currentStreak:0};
  if (cp.date!==todayStr) Object.assign(cp,{date:todayStr,sessionsToday:0,minsToday:0,bestScoreToday:0,perfectSessionToday:false,longestSessionToday:0,morningSession:false});
  if (cp.week!==weekStart()) Object.assign(cp,{week:weekStart(),sessionsThisWeek:0,minsThisWeek:0,cleanSessionsThisWeek:0,ultraSessionsThisWeek:0,scoresThisWeek:[]});
  cp.sessionsToday++;
  cp.minsToday+=durationMins;
  cp.bestScoreToday=Math.max(cp.bestScoreToday,session.focusScore);
  if (session.distractionAttempts===0) cp.perfectSessionToday=true;
  cp.longestSessionToday=Math.max(cp.longestSessionToday,durationMins);
  if (hour<12) cp.morningSession=true;
  cp.sessionsThisWeek++;
  cp.minsThisWeek+=durationMins;
  if (session.distractionAttempts===0) cp.cleanSessionsThisWeek++;
  if (session.ultraFocus) cp.ultraSessionsThisWeek=(cp.ultraSessionsThisWeek||0)+1;
  cp.scoresThisWeek.push(session.focusScore);
  cp.avgScoreThisWeek=Math.round(cp.scoresThisWeek.reduce((a,b)=>a+b,0)/cp.scoresThisWeek.length);
  cp.currentStreak=streakData.current;

  const completedChallenges=data.completedChallenges||[];
  const {daily,weekly}=getActiveChallenges();
  let challengeBonusXP={daily:0,weekly:0}, dailyCompleted=false, weeklyCompleted=false;
  const dailyKey=`${todayStr}-${daily.id}`, weeklyKey=`${weekStart()}-${weekly.id}`;
  if (!completedChallenges.includes(dailyKey) && checkChallenge(daily,cp)) {
    completedChallenges.push(dailyKey); challengeBonusXP.daily=daily.xpReward;
    playerStats.totalXP+=daily.xpReward; playerStats.challengesCompleted=(playerStats.challengesCompleted||0)+1; dailyCompleted=true;
  }
  if (!completedChallenges.includes(weeklyKey) && checkChallenge(weekly,cp)) {
    completedChallenges.push(weeklyKey); challengeBonusXP.weekly=weekly.xpReward;
    playerStats.totalXP+=weekly.xpReward; playerStats.challengesCompleted=(playerStats.challengesCompleted||0)+1; weeklyCompleted=true;
  }

  leaderboard.push({ goal:session.goal, xp:xpEarned, score:session.focusScore, duration:durationMins, ultraFocus:session.ultraFocus, date:new Date().toISOString() });
  leaderboard.sort((a,b)=>b.xp-a.xp);

  const recap={
    goal:session.goal, date:new Date().toISOString(), durationMins, focusScore:session.focusScore,
    distractionAttempts:session.distractionAttempts, tabsOpened:session.tabsOpened,
    xpEarned, totalXP:playerStats.totalXP, level:newLevel.current, leveledUp,
    newBadges:newBadgeIds.map(id=>BADGES.find(b=>b.id===id)),
    challengeBonusXP, dailyCompleted, weeklyCompleted,
    streak:streakData.current, ultraFocus:session.ultraFocus, completed
  };

  await chrome.storage.local.set({
    sessionHistory:[...history,recap].slice(-100),
    streakData, playerStats, earnedBadges,
    completedChallenges:completedChallenges.slice(-200),
    challengeProgress:cp, leaderboard:leaderboard.slice(0,50),
    activeSession:null, lastRecap:recap
  });

  chrome.alarms.clearAll();
  session=null;
  updateBadge(false, false);
}

function checkChallenge(ch, cp) {
  switch(ch.id) {
    case 'd1': return cp.sessionsToday>=2;
    case 'd2': return cp.minsToday>=60;
    case 'd3': return cp.bestScoreToday>=80;
    case 'd4': return cp.perfectSessionToday;
    case 'd5': return cp.longestSessionToday>=45;
    case 'd6': return cp.morningSession;
    case 'd7': return cp.sessionsToday>=3;
    case 'w1': return cp.minsThisWeek>=300;
    case 'w2': return cp.sessionsThisWeek>=10;
    case 'w3': return cp.currentStreak>=5;
    case 'w4': return cp.avgScoreThisWeek>=75;
    case 'w5': return (cp.ultraSessionsThisWeek||0)>=3;
    default: return false;
  }
}

// ── Tab Monitoring ────────────────────────────────────────────────────────────
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (!session||changeInfo.status!=='complete'||!tab.url) return;
  if (tab.url.startsWith('chrome://')||tab.url.startsWith('chrome-extension://')) return;
  session.tabsOpened++;
  const {customBlocklist=[],globalWhitelist=[],removedDefaults=[]} = await chrome.storage.local.get(['customBlocklist','globalWhitelist','removedDefaults']);
  if (isBlocked(tab.url, customBlocklist, globalWhitelist, session.sessionWhitelist, session.ultraFocus, removedDefaults)) {
    session.distractionAttempts++;
    session.focusScore=Math.max(0,session.focusScore-5);
    await chrome.storage.local.set({activeSession:session});
    try {
      await chrome.tabs.sendMessage(tabId, {
        type:'SHOW_DISTRACTION_WARNING',
        goal:session.goal, attempts:session.distractionAttempts,
        elapsed:Math.round((Date.now()-session.startTime)/60000),
        ultraFocus:session.ultraFocus
      });
    } catch(e){}
    return;
  }
  const score=scoreRelevance(tab.url,tab.title||'',session.keywords);
  if (score<20&&session.tabsOpened>3&&!session.ultraFocus) {
    try { await chrome.tabs.sendMessage(tabId,{type:'SHOW_LOW_RELEVANCE',score,goal:session.goal}); } catch(e){}
  }
});

// ── Messages ──────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  (async()=>{
    switch(msg.type){
      case 'START_SESSION':
        await startSession(msg.goal,msg.duration,msg.sessionWhitelist,msg.ultraFocus);
        sendResponse({ok:true}); break;
      case 'END_SESSION':
        await endSession(msg.completed); sendResponse({ok:true}); break;
      case 'GET_STATE':
        const s=await chrome.storage.local.get([
          'activeSession','sessionHistory','streakData','lastRecap',
          'playerStats','earnedBadges','leaderboard','completedChallenges',
          'challengeProgress','globalWhitelist','customBlocklist','removedDefaults','apiKey'
        ]);
        if (s.activeSession&&!session) session=s.activeSession;
        s.activeChallenges=getActiveChallenges();
        s.allBadges=BADGES; s.levels=LEVELS;
        s.defaultBlocklist=DEFAULT_BLOCKLIST;
        sendResponse(s); break;
      case 'SAVE_SETTINGS':
        await chrome.storage.local.set({globalWhitelist:msg.globalWhitelist,customBlocklist:msg.customBlocklist,removedDefaults:msg.removedDefaults||[],apiKey:msg.apiKey});
        sendResponse({ok:true}); break;
      case 'DISMISS_RECAP':
        await chrome.storage.local.remove('lastRecap'); sendResponse({ok:true}); break;
    }
  })(); return true;
});

// ── Alarms ────────────────────────────────────────────────────────────────────
chrome.alarms.onAlarm.addListener(async(alarm)=>{
  if (alarm.name==='sessionEnd') {
    await endSession(true);
    chrome.notifications.create({type:'basic',iconUrl:'icons/icon128.png',title:'🎯 FlowGuard – Session Complete!',message:'Great work! Check your XP and badges.'});
  }
  if (alarm.name==='sessionTick') {
    if (!session) { const {activeSession}=await chrome.storage.local.get('activeSession'); session=activeSession; }
    if (session) await chrome.storage.local.set({activeSession:session});
  }
});

function updateBadge(active, ultra) {
  chrome.action.setBadgeText({text:active?'●':''});
  chrome.action.setBadgeBackgroundColor({color:active?(ultra?'#f43f5e':'#6366f1'):'#9ca3af'});
}

chrome.storage.local.get('activeSession').then(({activeSession})=>{
  if (activeSession) { session=activeSession; updateBadge(true,activeSession.ultraFocus); }
});
