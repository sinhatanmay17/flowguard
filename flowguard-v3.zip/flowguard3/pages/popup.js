// FlowGuard v3 Popup JS

const $ = id => document.getElementById(id);
let timerInterval = null;
let sessionWhitelist = []; // [{name, domain, emoji}]
let focusMode = 'normal'; // 'normal' | 'ultra'
let customBlocklist = [];
let removedDefaults = [];

// ── Popular Sites Database for Search ────────────────────────────────────────
const SITE_DB = [
  {name:'YouTube',     domain:'youtube.com',       emoji:'▶️'},
  {name:'Netflix',     domain:'netflix.com',        emoji:'🎬'},
  {name:'Instagram',   domain:'instagram.com',      emoji:'📸'},
  {name:'Twitter/X',   domain:'twitter.com',        emoji:'🐦'},
  {name:'Facebook',    domain:'facebook.com',       emoji:'👤'},
  {name:'TikTok',      domain:'tiktok.com',         emoji:'🎵'},
  {name:'Reddit',      domain:'reddit.com',         emoji:'🤖'},
  {name:'Twitch',      domain:'twitch.tv',          emoji:'🎮'},
  {name:'Discord',     domain:'discord.com',        emoji:'💬'},
  {name:'WhatsApp',    domain:'whatsapp.com',       emoji:'💬'},
  {name:'Telegram',    domain:'telegram.org',       emoji:'✈️'},
  {name:'Notion',      domain:'notion.so',          emoji:'📝'},
  {name:'Wikipedia',   domain:'wikipedia.org',      emoji:'📚'},
  {name:'Google Docs', domain:'docs.google.com',    emoji:'📄'},
  {name:'Google Drive',domain:'drive.google.com',   emoji:'📁'},
  {name:'Gmail',       domain:'mail.google.com',    emoji:'📧'},
  {name:'Outlook',     domain:'outlook.com',        emoji:'📧'},
  {name:'GitHub',      domain:'github.com',         emoji:'💻'},
  {name:'Stack Overflow',domain:'stackoverflow.com',emoji:'💡'},
  {name:'Spotify',     domain:'spotify.com',        emoji:'🎵'},
  {name:'LinkedIn',    domain:'linkedin.com',       emoji:'💼'},
  {name:'Pinterest',   domain:'pinterest.com',      emoji:'📌'},
  {name:'Snapchat',    domain:'snapchat.com',       emoji:'👻'},
  {name:'Amazon',      domain:'amazon.com',         emoji:'📦'},
  {name:'Hulu',        domain:'hulu.com',           emoji:'📺'},
  {name:'Disney+',     domain:'disneyplus.com',     emoji:'🏰'},
  {name:'Quora',       domain:'quora.com',          emoji:'❓'},
  {name:'Medium',      domain:'medium.com',         emoji:'✍️'},
  {name:'Substack',    domain:'substack.com',       emoji:'📰'},
  {name:'Obsidian',    domain:'obsidian.md',        emoji:'💎'},
  {name:'Figma',       domain:'figma.com',          emoji:'🎨'},
  {name:'Canva',       domain:'canva.com',          emoji:'🎨'},
  {name:'Trello',      domain:'trello.com',         emoji:'📋'},
  {name:'Jira',        domain:'atlassian.com',      emoji:'🔧'},
  {name:'Slack',       domain:'slack.com',          emoji:'💬'},
  {name:'Zoom',        domain:'zoom.us',            emoji:'📹'},
  {name:'Google Meet', domain:'meet.google.com',    emoji:'📹'},
  {name:'ChatGPT',     domain:'chat.openai.com',    emoji:'🤖'},
  {name:'Claude',      domain:'claude.ai',          emoji:'🤖'},
  {name:'Khan Academy',domain:'khanacademy.org',    emoji:'🎓'},
  {name:'Coursera',    domain:'coursera.org',       emoji:'🎓'},
  {name:'Duolingo',    domain:'duolingo.com',       emoji:'🦜'},
  {name:'Chess.com',   domain:'chess.com',          emoji:'♟️'},
  {name:'BuzzFeed',    domain:'buzzfeed.com',       emoji:'🐝'},
  {name:'9GAG',        domain:'9gag.com',           emoji:'😂'},
  {name:'Tumblr',      domain:'tumblr.com',         emoji:'📷'},
  {name:'Yahoo',       domain:'yahoo.com',          emoji:'🟣'},
];

const DEFAULT_BLOCKLIST = [
  'youtube.com','netflix.com','instagram.com','twitter.com','x.com',
  'facebook.com','tiktok.com','reddit.com','twitch.tv','pinterest.com',
  'snapchat.com','discord.com','whatsapp.com','telegram.org',
  '9gag.com','buzzfeed.com','tumblr.com','quora.com','vk.com',
  'linkedin.com','hulu.com','disneyplus.com','primevideo.com'
];

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  setupTabs();
  setupModeToggle();
  setupSearch();
  setupEvents();
  await loadAll();
});

async function loadAll() {
  const state = await msg({type:'GET_STATE'});
  renderHeader(state);
  renderStreak(state);
  renderChallenges(state);
  renderLeaderboard(state);
  renderBadges(state);
  loadSettings(state);
  renderBlockedList(state);
  customBlocklist = state.customBlocklist || [];

  if (state.activeSession) showActive(state.activeSession);
  else if (state.lastRecap) showRecap(state.lastRecap, state);
  else showIdle();
}

// ── Header ────────────────────────────────────────────────────────────────────
function renderHeader(state) {
  const xp = (state.playerStats||{}).totalXP||0;
  const li = getLvInfo(xp, state.levels||[]);
  if (!li) return;
  $('hdr-icon').textContent = li.cur.icon;
  $('hdr-level').textContent = `Lv ${li.cur.level} · ${li.cur.title}`;
  $('xp-cur').textContent = `${xp} XP`;
  $('xp-nxt').textContent = li.nxt ? `Next: ${li.nxt.xpRequired} XP` : 'MAX LEVEL';
  $('xp-fill').style.width = `${li.prog}%`;
}

function getLvInfo(xp, levels) {
  if (!levels.length) return null;
  let cur=levels[0], nxt=levels[1];
  for (let i=levels.length-1;i>=0;i--) { if (xp>=levels[i].xpRequired){cur=levels[i];nxt=levels[i+1]||null;break;} }
  const into=xp-cur.xpRequired, needed=nxt?nxt.xpRequired-cur.xpRequired:1;
  return {cur,nxt,prog:nxt?Math.min((into/needed)*100,100):100};
}

function calcXP(mins,score,ultra){
  const m=score>=90?2.0:score>=75?1.5:score>=60?1.2:score>=40?1.0:0.7;
  return Math.round(mins*2*m*(ultra?1.5:1.0));
}

// ── Streak ────────────────────────────────────────────────────────────────────
function renderStreak(state) {
  const sd=state.streakData||{}, ps=state.playerStats||{};
  $('s-streak').textContent=sd.current||0;
  $('s-best').textContent=sd.longest||0;
  $('s-total').textContent=ps.totalSessions||0;
}

// ── Mode Toggle ───────────────────────────────────────────────────────────────
function setupModeToggle() {
  $('mode-normal').addEventListener('click', () => setMode('normal'));
  $('mode-ultra').addEventListener('click', () => setMode('ultra'));
}
function setMode(m) {
  focusMode = m;
  $('mode-normal').className = `mode-btn ${m==='normal'?'active-normal':''}`;
  $('mode-ultra').className = `mode-btn ${m==='ultra'?'active-ultra':''}`;
  $('ultra-warn').className = `ultra-warn ${m==='ultra'?'show':''}`;
}

// ── Whitelist Search ──────────────────────────────────────────────────────────
function setupSearch() {
  const inp = $('wl-search');
  const dd = $('wl-dropdown');

  inp.addEventListener('input', () => {
    const q = inp.value.trim().toLowerCase();
    if (!q) { dd.classList.remove('open'); return; }

    const results = SITE_DB.filter(s =>
      s.name.toLowerCase().includes(q) || s.domain.includes(q)
    ).slice(0, 7);

    // Also add custom entry if it looks like a domain
    const custom = q.includes('.') ? [{name:q, domain:q, emoji:'🌐'}] : [];
    const all = [...results, ...custom.filter(c => !results.find(r=>r.domain===c.domain))].slice(0,8);

    if (!all.length) { dd.classList.remove('open'); return; }

    dd.innerHTML = all.map(s => `
      <div class="search-item" data-domain="${esc(s.domain)}" data-name="${esc(s.name)}" data-emoji="${esc(s.emoji||'🌐')}">
        <div class="search-item-favicon">${s.emoji||'🌐'}</div>
        <div><div class="search-item-name">${esc(s.name)}</div><div class="search-item-url">${esc(s.domain)}</div></div>
      </div>`).join('');
    dd.classList.add('open');

    dd.querySelectorAll('.search-item').forEach(item => {
      item.addEventListener('click', () => {
        addWlTag({domain:item.dataset.domain, name:item.dataset.name, emoji:item.dataset.emoji});
        inp.value = '';
        dd.classList.remove('open');
      });
    });
  });

  inp.addEventListener('keydown', e => {
    if (e.key==='Enter') {
      const q=inp.value.trim();
      if (q) { addWlTag({domain:q.replace('https://','').replace('http://','').replace('www.','').split('/')[0], name:q, emoji:'🌐'}); inp.value=''; dd.classList.remove('open'); }
    }
    if (e.key==='Escape') dd.classList.remove('open');
  });

  document.addEventListener('click', e => { if (!e.target.closest('.search-wrap')) dd.classList.remove('open'); });
}

function addWlTag({domain, name, emoji}) {
  if (sessionWhitelist.find(t=>t.domain===domain)) return;
  sessionWhitelist.push({domain, name, emoji});
  renderTags();
}

function renderTags() {
  $('wl-tags').innerHTML = sessionWhitelist.map(t =>
    `<div class="tag"><span class="tag-favicon">${t.emoji||'🌐'}</span>${esc(t.name)}<span class="tag-x" data-domain="${esc(t.domain)}">✕</span></div>`
  ).join('');
  $('wl-tags').querySelectorAll('.tag-x').forEach(x => {
    x.addEventListener('click', () => {
      sessionWhitelist = sessionWhitelist.filter(t=>t.domain!==x.dataset.domain);
      renderTags();
    });
  });
}

// ── Blocked Sites List ────────────────────────────────────────────────────────
function buildBlockedHTML() {
  const activeDefaults = DEFAULT_BLOCKLIST.filter(d => !removedDefaults.includes(d));
  let html = '';
  if (customBlocklist.length) {
    html += `<div class="blocked-default-label">Custom</div>`;
    html += customBlocklist.map(d => `
      <div class="blocked-item">
        <span class="blocked-item-domain">${esc(d)}</span>
        <button class="blocked-item-remove" data-domain="${esc(d)}" data-type="custom">✕</button>
      </div>`).join('');
    if (activeDefaults.length) html += `<div class="blocked-divider"></div>`;
  }
  if (activeDefaults.length) {
    html += `<div class="blocked-default-label">Default (${activeDefaults.length} sites)</div>`;
    html += activeDefaults.map(d => `
      <div class="blocked-item">
        <span class="blocked-item-domain">${esc(d)}</span>
        <button class="blocked-item-remove" data-domain="${esc(d)}" data-type="default">✕</button>
      </div>`).join('');
  }
  return html;
}

function renderBlockedList(state) {
  customBlocklist = state.customBlocklist || [];
  removedDefaults = state.removedDefaults || [];
  const el = $('blocked-list');
  el.innerHTML = buildBlockedHTML();
  attachBlockedListeners();
}

function renderBlockedListDirect() {
  const el = $('blocked-list');
  el.innerHTML = buildBlockedHTML();
  attachBlockedListeners();
}

function attachBlockedListeners() {
  $('blocked-list').querySelectorAll('.blocked-item-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      if (btn.dataset.type === 'custom') {
        customBlocklist = customBlocklist.filter(d => d !== btn.dataset.domain);
      } else {
        if (!removedDefaults.includes(btn.dataset.domain)) removedDefaults.push(btn.dataset.domain);
      }
      renderBlockedListDirect();
    });
  });
}

// ── Challenges ────────────────────────────────────────────────────────────────
function renderChallenges(state) {
  const {daily,weekly}=state.activeChallenges||{};
  const cp=state.challengeProgress||{};
  const done=state.completedChallenges||[];
  const td=new Date().toDateString();
  const ws=(()=>{const d=new Date();d.setDate(d.getDate()-d.getDay());return d.toDateString();})();
  const dDone=done.includes(`${td}-${daily?.id}`), wDone=done.includes(`${ws}-${weekly?.id}`);
  const ps=state.playerStats||{};

  let html='';
  if (daily) {
    const p=Math.round(getDailyProg(daily,cp));
    html+=`<div class="challenge-card">
      <div class="ch-header"><span class="ch-type type-daily">Daily</span><span class="ch-xp">+${daily.xpReward} XP</span></div>
      <div class="ch-text">${daily.text}</div>
      <div class="ch-prog"><div class="ch-prog-fill fill-daily" style="width:${p}%"></div></div>
      <div class="ch-footer"><span>${p}% complete</span>${dDone?'<span class="ch-done-lbl">✓ Done!</span>':'<span>In progress</span>'}</div>
    </div>`;
  }
  if (weekly) {
    const p=Math.round(getWeeklyProg(weekly,cp));
    html+=`<div class="challenge-card">
      <div class="ch-header"><span class="ch-type type-weekly">Weekly</span><span class="ch-xp">+${weekly.xpReward} XP</span></div>
      <div class="ch-text">${weekly.text}</div>
      <div class="ch-prog"><div class="ch-prog-fill fill-weekly" style="width:${p}%"></div></div>
      <div class="ch-footer"><span>${p}% complete</span>${wDone?'<span class="ch-done-lbl">✓ Done!</span>':'<span>In progress</span>'}</div>
    </div>`;
  }
  html+=`<div class="card"><div class="label" style="margin-bottom:8px">Today's Stats</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <div><div style="font-size:18px;font-weight:800">${cp.sessionsToday||0}</div><div style="font-size:10px;color:var(--t3)">Sessions today</div></div>
      <div><div style="font-size:18px;font-weight:800">${cp.minsToday||0}m</div><div style="font-size:10px;color:var(--t3)">Focus time today</div></div>
      <div><div style="font-size:18px;font-weight:800">${cp.minsThisWeek||0}m</div><div style="font-size:10px;color:var(--t3)">This week</div></div>
      <div><div style="font-size:18px;font-weight:800">${ps.challengesCompleted||0}</div><div style="font-size:10px;color:var(--t3)">Challenges done</div></div>
    </div></div>`;
  $('challenges-content').innerHTML=html;
}

function getDailyProg(ch,cp){
  switch(ch.id){
    case 'd1':return Math.min(100,((cp.sessionsToday||0)/2)*100);
    case 'd2':return Math.min(100,((cp.minsToday||0)/60)*100);
    case 'd3':return Math.min(100,((cp.bestScoreToday||0)/80)*100);
    case 'd4':return cp.perfectSessionToday?100:0;
    case 'd5':return Math.min(100,((cp.longestSessionToday||0)/45)*100);
    case 'd6':return cp.morningSession?100:0;
    case 'd7':return Math.min(100,((cp.sessionsToday||0)/3)*100);
    default:return 0;
  }
}
function getWeeklyProg(ch,cp){
  switch(ch.id){
    case 'w1':return Math.min(100,((cp.minsThisWeek||0)/300)*100);
    case 'w2':return Math.min(100,((cp.sessionsThisWeek||0)/10)*100);
    case 'w3':return Math.min(100,((cp.currentStreak||0)/5)*100);
    case 'w4':return Math.min(100,((cp.avgScoreThisWeek||0)/75)*100);
    case 'w5':return Math.min(100,((cp.ultraSessionsThisWeek||0)/3)*100);
    default:return 0;
  }
}

// ── Leaderboard ───────────────────────────────────────────────────────────────
function renderLeaderboard(state) {
  const lb=state.leaderboard||[];
  const el=$('lb-list');
  if (!lb.length) { el.innerHTML=`<div style="text-align:center;padding:30px;color:var(--t3);font-size:12px">Complete sessions to appear here!</div>`; return; }
  const medals=['🥇','🥈','🥉'];
  el.innerHTML=lb.slice(0,10).map((e,i)=>`
    <div class="lb-entry">
      <div class="lb-rank">${medals[i]||(i+1)}</div>
      <div class="lb-info">
        <div class="lb-goal">${esc(e.goal)}${e.ultraFocus?'<span class="lb-ultra-badge">Ultra</span>':''}</div>
        <div class="lb-meta">${e.duration}min · Score ${e.score} · ${new Date(e.date).toLocaleDateString()}</div>
      </div>
      <div class="lb-xp">+${e.xp}</div>
    </div>`).join('');
}

// ── Badges ────────────────────────────────────────────────────────────────────
function renderBadges(state) {
  const all=state.allBadges||[], earned=state.earnedBadges||[];
  $('badge-count').textContent=`${earned.length} / ${all.length} unlocked`;
  $('badges-grid').innerHTML=all.map(b=>{
    const e=earned.includes(b.id);
    return `<div class="badge-item ${e?'earned':'locked'}">
      <div class="b-icon">${b.icon}</div>
      <div class="b-name">${b.name}</div>
      <div class="b-desc">${b.desc}</div>
    </div>`;
  }).join('');
}

// ── Settings ──────────────────────────────────────────────────────────────────
function loadSettings(state) {
  if (state.apiKey) { $('api-key').value=state.apiKey; $('api-status').textContent='● Connected'; $('api-status').className='api-pill api-on'; }
  if (state.globalWhitelist) $('global-wl').value=state.globalWhitelist.join('\n');
  removedDefaults = state.removedDefaults || [];
}

// ── Views ─────────────────────────────────────────────────────────────────────
function showIdle() {
  $('view-idle').style.display='block';
  $('view-active').style.display='none';
  $('view-recap').style.display='none';
}
function showActive(session) {
  $('view-idle').style.display='none';
  $('view-active').style.display='block';
  $('view-recap').style.display='none';
  const ultra=session.ultraFocus;
  $('mode-indicator-wrap').innerHTML=`<div class="mode-indicator ${ultra?'mode-ultra':'mode-normal'}">${ultra?'🔒 Ultra Focus':'🎯 Normal Focus'}</div>`;
  $('active-goal').innerHTML=`<strong>${esc(session.goal)}</strong>`;
  updateActiveStats(session);
  startTimer(session);
}
function showRecap(recap, state) {
  $('view-idle').style.display='none';
  $('view-active').style.display='none';
  $('view-recap').style.display='block';
  const score=recap.focusScore;
  const col=score>=70?'var(--green)':score>=40?'var(--orange)':'var(--red)';
  $('r-score').textContent=score; $('r-score').style.color=col;
  $('r-xp').textContent=`+${recap.xpEarned}`;
  $('r-dur').textContent=`${recap.durationMins}m`;
  $('r-dist').textContent=recap.distractionAttempts;
  $('r-tabs').textContent=recap.tabsOpened;
  $('r-streak').textContent=`${recap.streak}🔥`;
  $('r-msg').textContent=score>=90?'🏆 Perfect session!':(score>=70?'💪 Great work! Keep the streak going.':(score>=50?'📈 Good effort! Fewer distractions next time.':'🌱 Every session counts. You showed up!'));
  if (recap.leveledUp&&recap.level) {
    $('level-up').style.display='block';
    $('lu-text').textContent=`🎉 Level Up! ${recap.level.icon} ${recap.level.title}`;
    $('lu-sub').textContent=`You're now Level ${recap.level.level}`;
  } else { $('level-up').style.display='none'; }
  const newBadges=recap.newBadges||[];
  $('r-badges').innerHTML=newBadges.map(b=>`<div class="badge-chip">${b.icon} ${b.name}</div>`).join('');
  let chal='';
  if (recap.dailyCompleted) chal+=`<div class="ch-done"><span>🎯 Daily Challenge Complete!</span><span class="ch-done-xp">+${recap.challengeBonusXP?.daily} XP</span></div>`;
  if (recap.weeklyCompleted) chal+=`<div class="ch-done"><span>🏆 Weekly Challenge Complete!</span><span class="ch-done-xp">+${recap.challengeBonusXP?.weekly} XP</span></div>`;
  $('r-challenges').innerHTML=chal;
}

// ── Timer ─────────────────────────────────────────────────────────────────────
function updateActiveStats(s) {
  const score=s.focusScore;
  $('score').textContent=score;
  $('score').style.color=score>=70?'var(--green)':score>=40?'var(--orange)':'var(--red)';
  $('l-tabs').textContent=s.tabsOpened||0;
  $('l-blocked').textContent=s.distractionAttempts||0;
  const elapsed=Math.round((Date.now()-s.startTime)/60000);
  $('xp-est').textContent=`+${calcXP(elapsed,score,s.ultraFocus)} XP`;
}

function startTimer(session) {
  clearInterval(timerInterval);
  timerInterval=setInterval(async()=>{
    const now=Date.now(), elapsed=now-session.startTime, remaining=session.duration-elapsed;
    if (remaining<=0) { clearInterval(timerInterval); await loadAll(); return; }
    const rm=Math.floor(remaining/60000), rs=Math.floor((remaining%60000)/1000);
    $('timer').textContent=`${pad(rm)}:${pad(rs)}`;
    $('l-rem').textContent=`${rm}m`;
    $('prog').style.width=`${Math.min((elapsed/session.duration)*100,100)}%`;
    if (Math.floor(elapsed/1000)%5===0) {
      const st=await msg({type:'GET_STATE'});
      if (st.activeSession) updateActiveStats(st.activeSession);
    }
  },1000);
}

// ── Events ────────────────────────────────────────────────────────────────────
function setupEvents() {
  $('btn-start').addEventListener('click', async () => {
    const goal=$('goal-input').value.trim();
    if (!goal) { $('goal-input').focus(); $('goal-input').style.borderColor='var(--red)'; return; }
    $('goal-input').style.borderColor='';
    const duration=parseInt($('duration-select').value);
    const wlDomains=sessionWhitelist.map(t=>t.domain);
    await msg({type:'START_SESSION',goal,duration,sessionWhitelist:wlDomains,ultraFocus:focusMode==='ultra'});
    sessionWhitelist=[];
    const state=await msg({type:'GET_STATE'});
    showActive(state.activeSession);
  });

  $('btn-end').addEventListener('click', async () => {
    clearInterval(timerInterval);
    await msg({type:'END_SESSION',completed:false});
    const state=await msg({type:'GET_STATE'});
    if (state.lastRecap) showRecap(state.lastRecap,state);
    renderHeader(state); renderStreak(state); renderChallenges(state); renderLeaderboard(state); renderBadges(state);
  });

  $('btn-new').addEventListener('click', async () => {
    await msg({type:'DISMISS_RECAP'});
    const state=await msg({type:'GET_STATE'});
    renderHeader(state); renderStreak(state);
    setMode('normal');
    sessionWhitelist=[];
    renderTags();
    showIdle();
  });

  $('btn-add-blocked').addEventListener('click', () => {
    const v=$('add-blocked-input').value.trim().toLowerCase().replace(/https?:\/\//,'').replace('www.','').split('/')[0];
    if (v&&!customBlocklist.includes(v)&&!DEFAULT_BLOCKLIST.includes(v)) {
      customBlocklist.push(v); renderBlockedListDirect();
    }
    $('add-blocked-input').value='';
  });
  $('add-blocked-input').addEventListener('keydown', e => { if (e.key==='Enter') $('btn-add-blocked').click(); });

  $('btn-save').addEventListener('click', async () => {
    const apiKey=$('api-key').value.trim();
    const globalWhitelist=$('global-wl').value.trim().split('\n').map(s=>s.trim()).filter(Boolean);
    await msg({type:'SAVE_SETTINGS',apiKey,globalWhitelist,customBlocklist,removedDefaults});
    $('api-status').textContent=apiKey?'● Connected':'● Not connected';
    $('api-status').className=`api-pill ${apiKey?'api-on':'api-off'}`;
    const ok=$('save-ok'); ok.style.display='block';
    setTimeout(()=>ok.style.display='none',2000);
  });
}

// ── Tabs ──────────────────────────────────────────────────────────────────────
function setupTabs() {
  document.querySelectorAll('.tab').forEach(tab=>{
    tab.addEventListener('click',()=>{
      document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
      document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
      tab.classList.add('active');
      $(`tab-${tab.dataset.tab}`).classList.add('active');
    });
  });
}

// ── Utils ─────────────────────────────────────────────────────────────────────
function pad(n){return String(n).padStart(2,'0')}
function esc(s){return(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function msg(m){return new Promise(r=>chrome.runtime.sendMessage(m,r))}
